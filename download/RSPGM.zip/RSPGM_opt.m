function score = RSPGM_opt(ppi,times)



for i = 1:times
    disp(['This is the ', num2str(i), 'th calculation:' ])
    [~,~,~,Score,P]=RSPGM(ppi,500);
    P1(i) = P;
    SScore{i}= Score;
end


I = find(P1==min(P1));
score = SScore{I};
    

