load W % input adjacent matrix
times = 30; %input iteration time
score = RSPGM_opt(M,times); %calculate the realibility score for each protein pairs
save Worm_50c39_30 score % obtain the optimization score and save it



