function [Theta,beta,Degree,Score,P]=RSPGM(W,M,beta_old,Theta_old,Degree_old,n_iter,epsilon,display)
%Estimate the parameters in the generative network model considering degree
%information of each vertice in the graph
%Input:  W--adjacency matrix of graph
%        M--the number of latent factor (M=500)
%    beta_old--the initial value of beta 
% old_Theta--the old value of Theta matrix in the process of iteration 
%    n_iter--the number of iteration
%   epsilon--to control end of iteration
% Author: Zhu Yuan 
% Date 11/18/2014
num_of_vertex = size(W,1);
if nargin < 8
    display =1;
end
if nargin< 7
    epsilon =1e-3;
end
if nargin< 6
    n_iter=300;
end
if nargin < 5
    %     Degree_old = sum(W);
    %     Degree_old = Degree_old';
    Degree_old =ones(num_of_vertex,1);
end
if nargin < 4
    Theta_old =rand(num_of_vertex,M);
end
if nargin <3
    beta_old = zeros(M,1);
end
if nargin<2
    error('You need to input the adjacency matrix W and the latent factor number M');
end
%-------fit gammar----------------------------
d = sum(W,2);
stat = tabulate(d);
stat = stat(stat(:,2)~=0,:);
X = -log(stat(:,1));
Y = log(stat(:,2));
gammar1 = robustfit(X,Y);
gammar = gammar1(2);
%-------------------------------------------------
W = W+eye(size(W));
diff=1;
time=1;
while diff > epsilon && time < n_iter
    f1 = ((W.*(Degree_old*Degree_old'))./(1-exp(-(Degree_old*Degree_old').*(Theta_old*Theta_old'))+eps))*Theta_old;
    f2 = Degree_old*Degree_old'*Theta_old + 0.5*repmat(beta_old',num_of_vertex,1);
    Theta_new = Theta_old.*(f1./(f2+eps));
    Theta_new = Theta_new./repmat(sum(Theta_new,2)+eps,1,M);
    diff = norm(Theta_new - Theta_old,'fro');
    if display
        disp(['This is the ' num2str(time) 'th iterate']);
        disp(['The difference betweeen Theta is ' num2str(diff)]);
    end
    beta_new = num_of_vertex*ones(M,1)./(sum(Theta_new,1)+eps)';
    f3 = ((W.*(Theta_old*Theta_old'))./(1-exp(-(Degree_old*Degree_old').*(Theta_old*Theta_old'))+eps))*Degree_old;
    %  f4 = repmat(Degree_old,1,num_of_vertex).*(Theta_old*Theta_old')*Degree_old+0.5*gammar;
    f4 = (Theta_old*Theta_old')*Degree_old + gammar./(Degree_old+eps);
    %  f4 = (Theta_old*Theta_old')*Degree_old+0.5*gammar;
    Degree_new = Degree_old.*(f3./(f4+eps));
    Degree_new = num_of_vertex*(Degree_new/sum(Degree_new));
    Theta_new(Theta_new<0.0001)=0;
    Score = (Degree_new*Degree_new').*(Theta_new*Theta_new');
    P = - trace(W*log(1-exp(-Score)+eps))+trace((1-W)*Score)-num_of_vertex*ones(1,M)*log(beta_new)+gammar*ones(1,num_of_vertex)*log(Degree_new+eps)+ones(1,num_of_vertex)*Theta_new*beta_new;
    disp(['The P is ',num2str(P)]);
    Theta_old = Theta_new;
    beta_old = beta_new;
    Degree_old = Degree_new;
    time = time+1;
end
Theta = sparse(Theta_new);
beta = beta_new;
Degree = Degree_new;
Score = 1-exp(-(Degree*Degree').*(Theta*Theta'));
P = - trace(W*log(1-exp(-Score)+eps))+trace((1-W)*Score)-num_of_vertex*ones(1,M)*log(beta)+gammar*ones(1,num_of_vertex)*log(Degree+eps)+ones(1,num_of_vertex)*Theta*beta;


